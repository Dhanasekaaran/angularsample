import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StudentModel } from './app.component';


@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  private readonly url = "http://localhost:8000/api/addcustomer";

  private readonly url1 = "http://localhost:8000/api/allcustomer";

  private readonly url3 = "http://localhost:8000/api/deletecustomer";

  private readonly url4 = "http://localhost:8000/api/listcustomer";

  private readonly url2 = "http://localhost:8000/api/updatecustomer";


  constructor(private http:HttpClient) { }

  Create(data:StudentModel):Observable<StudentModel> {
    return this.http.post<StudentModel>(this.url,data);
  }

  Update(data:StudentModel):Observable<StudentModel> {
    return this.http.post<StudentModel>(this.url2,data);
  }

  getall():Observable<StudentModel[]> {
    return this.http.get<StudentModel[]>(this.url1);
  }

  getone(id:any):Observable<StudentModel> {
    return this.http.get<StudentModel>(this.url4+"?id="+id);
  }

  delete(id:any):Observable<StudentModel> {
    return this.http.get<StudentModel>(this.url3+"?id="+id );
  }
}
