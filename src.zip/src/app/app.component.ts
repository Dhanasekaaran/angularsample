import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiserviceService } from './apiservice.service';

export class StudentModel {
  id:any;
  name:string;
  location:string;
  mobile:number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})



export class AppComponent implements OnInit {
 student:StudentModel = new StudentModel();
 allstudent:any = []; 
 isEdit : boolean;

 constructor(private api:ApiserviceService) {}
 
 ngOnInit(): void {
  this.getallstudent();
 }
 onSubmit(form:NgForm) {
   //console.log(form.value);
   if(!this.isEdit) {
     delete form.value.id;
   this.api.Create(form.value).subscribe(resp => {
     console.log(resp);
     form.resetForm();
     this.getallstudent();
   });
  }
  else {
    console.log(form.value);
    
    this.api.Update(form.value).subscribe(resp => {
      console.log(resp);
      form.resetForm();
      this.getallstudent();
      this.isEdit = false;
    });
  }
   
 }

 getallstudent() {
   this.api.getall().subscribe(resp => {
     console.log(resp['data']);
     this.allstudent = resp['data'];
     
   });
 }

 edit(data:StudentModel) {
  this.api.getone(data.id).subscribe(resp => {
    console.log(resp);
    this.student = resp['data'];
    this.isEdit = true;
  });
 }

 delete(data:StudentModel) {
  console.log(data);
  const isconf = window.confirm('Are you sure?');
  if(isconf) {
  this.api.delete(data.id).subscribe(resp => {
    console.log(resp);
    this.getallstudent();
  });
  }

  
 }
}
