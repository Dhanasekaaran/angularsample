import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddRoutingModule } from './add-routing.module';
import { InsertComponent } from './insert/insert.component';


@NgModule({
  declarations: [
    InsertComponent
  ],
  imports: [
    CommonModule,
    AddRoutingModule
  ]
})
export class AddModule {
  constructor() {
  console.log('add');
  }
  
 }
